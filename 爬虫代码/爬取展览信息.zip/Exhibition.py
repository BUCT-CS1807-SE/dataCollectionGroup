import requests
from lxml import etree
import pandas as pd
import openpyxl
from tqdm import tqdm
from selenium import webdriver

# 1.指定url
def changjiangcp():  # 开始按照网址访问网站，并填写基本信息
    wb=openpyxl.load_workbook('pycode/museum_info/Exhibits.xlsx')
    sheet=wb.active
    # 2.UA伪装
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36 SE 2.X MetaSr 1.0'
    }

    url = 'http://www.changjiangcp.com/list/130.html'  # 指定网址
    page_text = requests.get(url=url, headers=headers).text
    # 4.生成实例对象
    tree = etree.HTML(page_text)
    name = tree.xpath('//div[@class="inner"]/h2/text()')
    for i in range(14,14+len(name)):
        sheet.cell(row=i,column=5).value=name[i-14]
    wb.save('pycode/museum_info/Exhibits.xlsx')

def zhongshanwarship():  # 开始按照网址访问网站，并填写基本信息
    wb=openpyxl.load_workbook('pycode/museum_info/Exhibits.xlsx')
    sheet=wb.active
    browser=webdriver.Firefox()
    browser.get("http://www.zhongshanwarship.org.cn/zhanlaninfo.html?id=45")
    # 2.UA伪装
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36 SE 2.X MetaSr 1.0'
    }

    page_text = browser.page_source
    # 4.生成实例对象
    tree = etree.HTML(page_text)
    name = tree.xpath('//div[@class="am-u-sm-6 am-u-md-4 am-u-lg-3"]/div[@class="case-list-item"]/a/span[@class="areaName"]/text()')
    img=tree.xpath('//div[@class="case-list-item"]/a/img/@src')
    # lianjie=tree.xpath('//div[@class="case-list-item"]/a/@href')
    for i in range(len(name)):
        sheet.cell(row=i+23,column=5).value=name[i]
    wb.save('pycode/museum_info/Exhibits.xlsx')
    count=1
    for figu_url in img:
        img_name = str(count)+'.jpg'
        img_path = './photos/' + img_name
        img_data = requests.get(figu_url, headers=headers).content
        with open(img_path, 'wb') as fp:
            fp.write(img_data)
            print(img_name + '下载完成')
        count=count+1

def hubei():
    wb=openpyxl.load_workbook('pycode/museum_info/Exhibits.xlsx')
    sheet=wb.active
    browser=webdriver.Firefox()
    browser.get("http://wlt.hubei.gov.cn/1911museum/wwzz/hz/")
    # 2.UA伪装
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36 SE 2.X MetaSr 1.0'
    }

    page_text = browser.page_source
    # 4.生成实例对象
    tree = etree.HTML(page_text)
    name = tree.xpath('//li[@class="col-md-4 col-xs-6"]/a/h4[@class="tc"]/text()')
    img=tree.xpath('//span[@class="pic"]/img/@src')
    for i in range(len(name)):
        sheet.cell(row=i+61,column=5).value=name[i]
    wb.save('pycode/museum_info/Exhibits.xlsx')
    count=7
    for figu_url in img:
        figu_url='http://wlt.hubei.gov.cn/1911museum/wwzz/hz'+figu_url[1:]
        img_name = str(count)+'.jpg'
        img_path = './photos/' + img_name
        img_data = requests.get(figu_url, headers=headers).content
        with open(img_path, 'wb') as fp:
            fp.write(img_data)
            print(img_name + '下载完成')
        count=count+1


def whgmbwg():
    # wb=openpyxl.load_workbook('展品.xlsx')
    # sheet=wb.active
    browser=webdriver.Firefox()
    browser.get("http://www.whgmbwg.com/clzl/fycl/index_2.shtml")
    # 2.UA伪装
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36 SE 2.X MetaSr 1.0'
    }

    page_text = browser.page_source
    # 4.生成实例对象
    tree = etree.HTML(page_text)
    name = tree.xpath('//div[@class="gmg_ntwlb"]/ul/li/a/p/text()')
    img=tree.xpath('//div[@class="gmg_ntwlb"]/ul/li/a/img/@src')
    print(name)

    # print(img)
    # for i in range(len(name)):
    #     sheet.cell(row=i+75,column=5).value=name[i]
    # wb.save('展品.xlsx')
    count=1
    for figu_url in img:
        figu_url='http://www.whgmbwg.com'+figu_url
        img_name = str(count)+'.jpg'
        img_path = './photos/' + img_name
        img_data = requests.get(figu_url, headers=headers).content
        with open(img_path, 'wb') as fp:
            fp.write(img_data)
            print(img_name + '下载完成')
        count=count+1


def szbwg():
    wb=openpyxl.load_workbook('pycode/museum_info/Exhibits.xlsx')
    sheet=wb.active
    browser=webdriver.Firefox()
    browser.get("https://www.szbwg.net/show-11-144-1.html")
    # 2.UA伪装
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36 SE 2.X MetaSr 1.0'
    }

    page_text = browser.page_source
    # 4.生成实例对象
    tree = etree.HTML(page_text)
    # name = tree.xpath('/html/body/div[3]/div/div[2]/div/div[2]/div[2]/br/text()')
    img=tree.xpath('/html/body/div[3]/div/div[2]/div/div[2]/div[2]/img/@src')
    # for i in range(len(name)):
    #     sheet.cell(row=i+75,column=5).value=name[i]
    # wb.save('展品.xlsx')
    count=1
    for figu_url in img:
        figu_url=figu_url
        img_name = str(count)+'.jpg'
        img_path = './photos/' + img_name
        img_data = requests.get(figu_url, headers=headers).content
        with open(img_path, 'wb') as fp:
            fp.write(img_data)
            print(img_name + '下载完成')
        count=count+1

def ycbwg():
    # wb=openpyxl.load_workbook('展品.xlsx')
    # sheet=wb.active
    browser=webdriver.Firefox()

    browser.get("http://www.ycbwg.com/web/explore/collection/list.shtml")
    # 2.UA伪装
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36 SE 2.X MetaSr 1.0'
    }

    page_text = browser.page_source
    # 4.生成实例对象
    tree = etree.HTML(page_text)
    img = tree.xpath('//div[@class="img-box"]/a/img/@src')
    name=tree.xpath('//div[@class="listitem-summary"]/a/h5/span/text()')

    # for i in range(len(name)):
    #     sheet.cell(row=i+94,column=5).value=name[i]
    # wb.save('展品.xlsx')
    count=1
    for figu_url in img:
        figu_url='http://www.ycbwg.com'+figu_url
        img_name = str(count)+'.jpg'
        img_path = './photos/' + img_name
        img_data = requests.get(figu_url, headers=headers).content
        with open(img_path, 'wb') as fp:
            fp.write(img_data)
            print(img_name + '下载完成')
        count=count+1


def jzmsm():
    wb=openpyxl.load_workbook('pycode/museum_info/Exhibits.xlsx')
    sheet=wb.active
    browser=webdriver.Firefox()

    browser.get("http://www.jzmsm.org/yk/cangpin/guobaoxinshang/")
    # 2.UA伪装
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36 SE 2.X MetaSr 1.0'
    }

    page_text = browser.page_source
    # 4.生成实例对象
    tree = etree.HTML(page_text)
    img = tree.xpath('//div[@class="gbxs"]/ul/li/a/img/@src')
    name=tree.xpath('//div[@class="gbxs"]/ul/li/a/text()')
    for i in range(len(name)):
        sheet.cell(row=i+107,column=5).value=name[i]
    wb.save('pycode/museum_info/Exhibits.xlsx')
    count=1
    for figu_url in img:
        figu_url='http://www.jzmsm.org'+figu_url
        img_name = str(count)+'.jpg'
        img_path = './photos/' + img_name
        img_data = requests.get(figu_url, headers=headers).content
        with open(img_path, 'wb') as fp:
            fp.write(img_data)
            print(img_name + '下载完成')
        count=count+1


def boyue():
    wb=openpyxl.load_workbook('pycode/museum_info/Exhibits.xlsx')
    sheet=wb.active
    browser=webdriver.Firefox()

    browser.get("https://boyue.cnki.net/ExhibitionDetail?exid=86")
    # 2.UA伪装
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36 SE 2.X MetaSr 1.0'
    }

    page_text = browser.page_source
    # 4.生成实例对象
    tree = etree.HTML(page_text)
    img = tree.xpath('//div[@class="gbxs"]/ul/li/a/img/@src')
    name=tree.xpath('//div[@class="gbxs"]/ul/li/a/text()')
    for i in range(len(name)):
        sheet.cell(row=i+107,column=5).value=name[i]
    wb.save('pycode/museum_info/Exhibits.xlsx')
    count=1
    for figu_url in img:
        figu_url='http://www.jzmsm.org'+figu_url
        img_name = str(count)+'.jpg'
        img_path = './photos/' + img_name
        img_data = requests.get(figu_url, headers=headers).content
        with open(img_path, 'wb') as fp:
            fp.write(img_data)
            print(img_name + '下载完成')
        count=count+1
changjiangcp()
zhongshanwarship()
hubei()
whgmbwg()
szbwg()
ycbwg()
jzmsm()
boyue()






